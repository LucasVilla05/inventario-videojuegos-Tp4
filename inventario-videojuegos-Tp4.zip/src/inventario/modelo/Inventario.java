package inventario.modelo;

import java.util.*;

public class Inventario {
    private ArrayList<Videojuego> lista;

    public Inventario() {
        lista = new ArrayList<>();
    }

    public void agregar(Videojuego juego) {
        lista.add(juego);
    }

    public void mostrar() {
        for (Videojuego vj : lista) {
            vj.mostrar();
        }
    }

    public boolean contiene(String titulo) {
        for (Videojuego vj : lista) {
            if (vj.getTitulo().equalsIgnoreCase(titulo)) {
                return true;
            }
        }
        return false;
    }

    public boolean eliminar(String titulo) {
        Iterator<Videojuego> iter = lista.iterator();
        while (iter.hasNext()) {
            if (iter.next().getTitulo().equalsIgnoreCase(titulo)) {
                iter.remove();
                return true;
            }
        }
        return false;
    }

    public void ordenarAlfabeticamente() {
        lista.sort(Comparator.comparing(Videojuego::getTitulo));
    }

    public void detectarDuplicados() {
        Map<String, Integer> contador = new HashMap<>();
        for (Videojuego vj : lista) {
            contador.put(vj.getTitulo(), contador.getOrDefault(vj.getTitulo(), 0) + 1);
        }

        boolean duplicado = false;
        for (Map.Entry<String, Integer> entry : contador.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.println("⚠ Juego duplicado: " + entry.getKey() + " (x" + entry.getValue() + ")");
                duplicado = true;
            }
        }

        if (!duplicado) {
            System.out.println("✅ No hay juegos duplicados.");
        }
    }

    public ArrayList<Videojuego> getLista() {
        return lista;
    }
}
