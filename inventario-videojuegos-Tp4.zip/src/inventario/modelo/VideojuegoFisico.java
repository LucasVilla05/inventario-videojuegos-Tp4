package inventario.modelo;

public class VideojuegoFisico extends Videojuego {
    private String formato;

    public VideojuegoFisico(String titulo, String genero, String plataforma, String fecha, String estado, String formato) {
        super(titulo, genero, plataforma, fecha, estado);
        this.formato = formato;
    }

    @Override
    public void mostrar() {
        super.mostrar();
        System.out.println("Formato: " + formato);
    }

    public String getFormato() {
        return formato;
    }
}
