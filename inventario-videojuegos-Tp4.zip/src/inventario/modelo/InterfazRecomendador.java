package inventario.modelo;

public interface InterfazRecomendador {
    void recomendar();
}
