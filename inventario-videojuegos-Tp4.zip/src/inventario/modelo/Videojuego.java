package inventario.modelo;

public class Videojuego {
    protected String titulo;
    protected String genero;
    protected String plataforma;
    protected String fechaAdquisicion;
    protected String estado;

    public Videojuego(String titulo, String genero, String plataforma, String fechaAdquisicion, String estado) {
        this.titulo = titulo;
        this.genero = genero;
        this.plataforma = plataforma;
        this.fechaAdquisicion = fechaAdquisicion;
        this.estado = estado;
    }

    public void mostrar() {
        System.out.println("Título: " + titulo + ", Plataforma: " + plataforma + ", Estado: " + estado);
    }

    public String getTitulo() { return titulo; }
    public String getGenero() { return genero; }
    public String getPlataforma() { return plataforma; }
    public String getFechaAdquisicion() { return fechaAdquisicion; }
    public String getEstado() { return estado; }
}
